// public/app.js
document.addEventListener('DOMContentLoaded', () => {
  // nav
  document.querySelectorAll('nav button').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.panel').forEach(p => p.classList.add('hidden'));
      const sec = document.getElementById(btn.dataset.section);
      if (sec) sec.classList.remove('hidden');
    });
  });

  // default open
  document.querySelector('nav button[data-section="add-user"]').click();

 /**************************************
 * CREATE USER
 **************************************/
document.getElementById("form-add-user").addEventListener("submit", async (e) => {
    e.preventDefault();

    const form = e.target;
    const fName = form.fName.value;
    const lName = form.lName.value;
    const password = form.password.value;
    const dateOfBirth = form.dateOfBirth.value;

    const out = document.getElementById("out-add-user");

    try {
        const res = await fetch("/api/users", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ fName, lName, password, dateOfBirth })
        });

        // ⬅️ IMPORTANT: read the response as TEXT
        const text = await res.text();

        if (!res.ok) {
            out.textContent = "Error: " + text;
            return;
        }

        out.textContent = text;  // Backend already sends a string like "User created with ID: 12"
        form.reset();

    } catch (err) {
        out.textContent = "Network error: " + err.message;
    }
});


/**************************************
 * UPDATE USER FIRST NAME
 **************************************/
document.getElementById("form-update-user-name").addEventListener("submit", async (e) => {
    e.preventDefault();

    const form = e.target;

    const userID = form.userID.value;
    const password = form.password.value;
    const newFName = form.newFName.value;

    const out = document.getElementById("out-update-user-name");

    try {
        const res = await fetch("/api/users/update-name", {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ userID, password, newFName })
        });

        const data = await res.json();

        if (!res.ok) {
            out.textContent = "Error: " + (data.error || "Unknown error");
            return;
        }

        out.textContent = data.message;
        form.reset();

    } catch (err) {
        out.textContent = "Network error: " + err.message;
    }
});

/**************************************
 * VIEW USER FIRST NAME
 **************************************/
// VIEW USER FIRST NAME
document.getElementById("form-view-user").addEventListener("submit", async (e) => {
    e.preventDefault();

    const form = e.target;
    const userID = form.userID.value;
    const out = document.getElementById("out-view-user");

    try {
        const res = await fetch(`/api/users/${userID}`);

        const text = await res.text();  // server returns plain STRING

        out.textContent = text;

    } catch (err) {
        out.textContent = "Network error: " + err.message;
    }
});




  /**************************************
 * CREATE PORTFOLIO
 **************************************/
document.getElementById("form-create-portfolio").addEventListener("submit", async (e) => {
    e.preventDefault();

    const form = e.target;
    const userID = form.userID.value;
    const baseCurrency = form.baseCurrency.value;
    const out = document.getElementById("out-create-portfolio");

    try {
        const res = await fetch("/api/portfolios", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ userID, baseCurrency })
        });

        const data = await res.json();

        if (!res.ok) {
            out.textContent = "Error: " + (data.error || "Unknown error");
            return;
        }

        out.textContent = `Portfolio created!\nPortfolio ID: ${data.portfolioID}`;
        form.reset();
    } catch (err) {
        out.textContent = "Network error: " + err.message;
    }
});


/**************************************
 * LOAD PORTFOLIOS FOR A SPECIFIC USER
 **************************************/
document.getElementById("form-view-portfolios").addEventListener("submit", async (e) => {
    e.preventDefault();

    const form = e.target;
    const userID = form.userID.value.trim();
    const out = document.getElementById("out-view-portfolios");

    const table = document.getElementById("tbl-portfolios");
    const tbody = table.querySelector("tbody");

    if (!userID) {
        out.textContent = "Please enter a userID.";
        return;
    }

    try {
        const res = await fetch(`/api/portfolios/user/${userID}`);
        const portfolios = await res.json();

        if (!res.ok) {
            out.textContent = "Error: " + (portfolios.error || "Unknown error");
            table.classList.add("hidden");
            return;
        }

        out.textContent = `${portfolios.length} portfolio(s) found for user ${userID}.`;

        // Clear table body
        tbody.innerHTML = "";

        // Add rows
        portfolios.forEach(p => {
            const tr = document.createElement("tr");

            tr.innerHTML = `
                <td>${p.portfolioID}</td>
                <td>${p.userID}</td>
                <td>${p.baseCurrency || ""}</td>
                <td>
                    <button data-id="${p.portfolioID}" class="btn-delete">Delete</button>
                </td>
            `;

            tbody.appendChild(tr);
        });

        table.classList.remove("hidden");

    } catch (err) {
        out.textContent = "Network error: " + err.message;
        table.classList.add("hidden");
    }
});


/**************************************
 * DELETE PORTFOLIO (Any delete button)
 **************************************/
document.addEventListener("click", async (e) => {
    if (!e.target.classList.contains("btn-delete")) return;

    const id = e.target.dataset.id;
    if (!confirm(`Delete portfolio ${id}?`)) return;

    try {
        const res = await fetch(`/api/portfolios/${id}`, {
            method: "DELETE"
        });

        const data = await res.json();

        if (!res.ok) {
            alert("Error: " + (data.error || "Unknown error"));
            return;
        }

        alert(`Portfolio ${id} deleted`);

        // Auto-refresh if the user is currently viewing portfolios
        const form = document.getElementById("form-view-portfolios");
        if (form.userID.value.trim()) {
            form.dispatchEvent(new Event("submit"));
        }

    } catch (err) {
        alert("Network error: " + err.message);
    }
});

  /**************************************
 * CREATE ACCOUNT
 **************************************/
document.getElementById("form-create-account").addEventListener("submit", async (e) => {
    e.preventDefault();

    const form = e.target;
    const accountID = form.accountID.value.trim();
    const userID = form.userID.value.trim();
    const accountType = form.accountType.value;
    const out = document.getElementById("out-create-account");

    try {
        const res = await fetch("/api/accounts", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ accountID, userID, accountType })
        });

        const data = await res.json();

        if (!res.ok) {
            out.textContent = "Error: " + (data.error || "Unknown error");
            return;
        }

        out.textContent = `Account created!\nAccount ID: ${data.accountID}`;
        form.reset();
    } catch (err) {
        out.textContent = "Network error: " + err.message;
    }
});


/**************************************
 * LOAD ACCOUNTS FOR A SPECIFIC USER
 **************************************/
document.getElementById("form-view-accounts").addEventListener("submit", async (e) => {
    e.preventDefault();

    const form = e.target;
    const userID = form.userID.value.trim();
    const out = document.getElementById("out-view-accounts");

    const table = document.getElementById("tbl-accounts");
    const tbody = table.querySelector("tbody");

    if (!userID) {
        out.textContent = "Please enter a userID.";
        return;
    }

    try {
        const res = await fetch(`/api/accounts/user/${userID}`);
        const accounts = await res.json();

        if (!res.ok) {
            out.textContent = "Error: " + (accounts.error || "Unknown error");
            table.classList.add("hidden");
            return;
        }

        out.textContent = `${accounts.length} account(s) found for user ${userID}.`;

        // Clear rows
        tbody.innerHTML = "";

        // Populate table
        accounts.forEach(acc => {
        const tr = document.createElement("tr");

        tr.innerHTML = `
            <td>${acc.accountID}</td>
            <td>${acc.institutionNumber}</td>
            <td>${acc.transitNumber}</td>
            <td>${acc.accountNumber}</td>
            <td>${acc.accountType}</td>
            <td><button data-id="${acc.accountID}" class="btn-delete-account">Delete</button></td>
        `;

        tbody.appendChild(tr);
        });


        table.classList.remove("hidden");

    } catch (err) {
        out.textContent = "Network error: " + err.message;
        table.classList.add("hidden");
    }
});


/**************************************
 * DELETE ACCOUNT
 **************************************/
document.addEventListener("click", async (e) => {
    if (!e.target.classList.contains("btn-delete-account")) return;

    const id = e.target.dataset.id;
    if (!confirm(`Delete account ${id}?`)) return;

    try {
        const res = await fetch(`/api/accounts/${id}`, {
            method: "DELETE"
        });

        const data = await res.json();

        if (!res.ok) {
            alert("Error: " + (data.error || "Unknown error"));
            return;
        }

        alert(`Account ${id} deleted`);

        // Auto refresh if user is viewing accounts
        const form = document.getElementById("form-view-accounts");
        if (form.userID.value.trim()) {
            form.dispatchEvent(new Event("submit"));
        }

    } catch (err) {
        alert("Network error: " + err.message);
    }
});

/**************************************
 * CREATE INVESTMENT
 **************************************/
document.getElementById("form-create-investment").addEventListener("submit", async (e) => {
    e.preventDefault();

    const form = e.target;

    const tickerSymbol = form.tickerSymbol.value;
    const sector = form.sector.value;
    const region = form.region.value;
    const nativeCurrency = form.nativeCurrency.value || "USD";
    const investmentType = form.investmentType.value;

    const out = document.getElementById("out-create-investment");

    try {
        const res = await fetch("/api/investments", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                tickerSymbol,
                sector,
                region,
                nativeCurrency,
                investmentType
            })
        });

        const text = await res.text();  // backend returns string

        if (!res.ok) {
            out.textContent = "Error: " + text;
            return;
        }

        out.textContent = text;
        form.reset();

    } catch (err) {
        out.textContent = "Network error: " + err.message;
    }
});

/**************************************
 * VIEW INVESTMENT
 **************************************/
document.getElementById("form-view-investment").addEventListener("submit", async (e) => {
    e.preventDefault();

    const form = e.target;
    const tickerSymbol = form.tickerSymbol.value;

    const out = document.getElementById("out-view-investment");

    try {
        const res = await fetch(`/api/investments/${tickerSymbol}`);

        const text = await res.text();  // backend sends plain text

        out.textContent = text;

    } catch (err) {
        out.textContent = "Network error: " + err.message;
    }
});

/**************************************
 * CREATE TRANSACTION
 **************************************/
document.getElementById("form-create-transaction").addEventListener("submit", async (e) => {
    e.preventDefault();

    const form = e.target;

    const transactionID = form.transactionID.value;
    const portfolioID = form.portfolioID.value;
    const tickerSymbol = form.tickerSymbol.value;
    const investmentType = form.investmentType.value; // optional
    const marketPricePerShare = form.marketPricePerShare.value;
    const salePricePerShare = form.salePricePerShare.value || null;
    const quantity = form.quantity.value;
    const transactionDate = form.transactionDate.value;

    const out = document.getElementById("out-create-transaction");

    try {
        const res = await fetch("/api/transactions", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                transactionID,
                portfolioID,
                tickerSymbol,
                investmentType,
                marketPricePerShare,
                salePricePerShare,
                quantity,
                transactionDate
            })
        });

        const text = await res.text();

        if (!res.ok) {
            out.textContent = "Error: " + text;
            return;
        }

        out.textContent = text;
        form.reset();

    } catch (err) {
        out.textContent = "Network error: " + err.message;
    }
});

/**************************************
 * VIEW TRANSACTION
 **************************************/
document.getElementById("form-view-transaction").addEventListener("submit", async (e) => {
    e.preventDefault();

    const form = e.target;

    const transactionID = form.transactionID.value;
    const out = document.getElementById("out-view-transaction");

    try {
        const res = await fetch(`/api/transactions/${transactionID}`);

        const text = await res.text();  // backend returns string

        out.textContent = text;

    } catch (err) {
        out.textContent = "Network error: " + err.message;
    }
});

 



  document.getElementById('btn-aggregate').addEventListener('click', async () => {
    const out = document.getElementById('out-reports');
    const table = document.getElementById('tbl-agg');
    const tbody = table.querySelector('tbody');
    tbody.innerHTML = '';
    try {
      const resp = await fetch('/api/reports/sector-aggregate');
      const j = await resp.json();
      if (j.rows && j.rows.length) {
        j.rows.forEach(r => {
          const tr = document.createElement('tr');
          tr.innerHTML = `<td>${r.sector}</td><td>${r.holdingsCount}</td><td>${r.totalBookCost}</td><td>${r.totalMarketValue}</td>`;
          tbody.appendChild(tr);
        });
        table.classList.remove('hidden');
        out.textContent = `${j.rows.length} sectors`;
      } else {
        table.classList.add('hidden');
        out.textContent = 'No aggregation data';
      }
    } catch (err) {
      out.textContent = 'Network error: ' + err.message;
    }
  });
});
