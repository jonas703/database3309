// server.js
require("dotenv").config();
const express = require("express");
const path = require("path");
const STATIC_DIR = path.join(__dirname, "public");
const db = require("./db"); // your mysql2/promise pool

const app = express();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static frontend
app.use(express.static(path.join(__dirname, "public")));

// ---- ROUTES ---- //
app.use("/api/portfolios", require("./routes/portfolios"));
app.use("/api/investments", require("./routes/investments"));
app.use("/api/transactions", require("./routes/transactions"));
app.use("/api/holdings", require("./routes/holdings"));
app.use("/api/accounts", require("./routes/accounts"));
app.use("/api/admin", require("./routes/admin"));
app.use("/api/users", require("./routes/users"));


// Basic health check
app.get("/api/health", async (req, res) => {
    try {
        const [rows] = await db.query("SELECT 1");
        res.json({ status: "OK", db: true });
    } catch (err) {
        res.status(500).json({ status: "ERROR", db: false });
    }
});

// Put AFTER all API routes
app.get('*', (req, res, next) => {
  // Only serve index.html for non-API routes
  if (req.path.startsWith('/api/') || req.path.startsWith('/static/')) return next();
  res.sendFile(path.join(STATIC_DIR, 'index.html'), err => {
    if (err) next(err);
  });
});

// Start server
const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log(`✔ Server running on http://localhost:${PORT}`);
});
