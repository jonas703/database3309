// routes/holdings.js
const express = require("express");
const router = express.Router();
const db = require("../db");

// GET all holdings
router.get("/", async (req, res) => {
    try {
        const [rows] = await db.query("SELECT * FROM Holding");
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: "Could not fetch holdings" });
    }
});

// GET holdings by portfolio
router.get("/portfolio/:id", async (req, res) => {
    try {
        const [rows] = await db.query(
            "SELECT * FROM Holding WHERE portfolioID = ?",
            [req.params.id]
        );
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: "Failed" });
    }
});

// UPDATE holding market value or book cost
router.put("/:portfolio/:ticker", async (req, res) => {
    try {
        const { quantityOwned, bookCost, marketValue } = req.body;

        const sql = `
            UPDATE Holding
            SET quantityOwned = COALESCE(?, quantityOwned),
                bookCost = COALESCE(?, bookCost),
                marketValue = COALESCE(?, marketValue)
            WHERE portfolioID = ? AND tickerSymbol = ?
        `;

        await db.query(sql, [
            quantityOwned || null,
            bookCost || null,
            marketValue || null,
            req.params.portfolio,
            req.params.ticker
        ]);

        res.json({ message: "Holding updated" });
    } catch (err) {
        res.status(500).json({ error: "Update failed" });
    }
});

module.exports = router;
