const express = require("express");
const router = express.Router();
const db = require("../db");

//Make
router.post("/", async (req, res) => {
  try {
    const { fName, lName, password, dateOfBirth } = req.body;

    if (!password || password.length < 8 || !/\d/.test(password)) {
      return res.status(400).json({ error: "Password is too weak" });
    }

    const sql = `
      INSERT INTO UserProfile (fName, lName, password, dateOfBirth)
      VALUES (?, ?, ?, ?)
    `;

    const [result] = await db.query(sql, [
      fName,
      lName,
      password,
      dateOfBirth
    ]);

    return res.send(`User created with ID: ${result.insertId}`);

  } catch (err) {
    console.error("USER CREATE ERROR:", err);
    return res.status(500).json({ error: "Database error", detail: err.message });
  }
});

/**
 * UPDATE FIRST NAME (with password verification)
 */
router.put("/update-name", async (req, res) => {
    try {
        const { userID, password, newFName } = req.body;

        // Validate input
        if (!userID || !password || !newFName) {
            return res.status(400).json({ error: "Missing required fields" });
        }

        // 1. Check user & verify password
        const [rows] = await db.query(
            "SELECT password FROM UserProfile WHERE userID = ?",
            [userID]
        );

        if (rows.length === 0) {
            return res.status(404).json({ error: "User not found" });
        }

        const storedPassword = rows[0].password;

        if (storedPassword !== password) {
            return res.status(403).json({ error: "Incorrect password" });
        }

        // 2. Update first name
        const [updateResult] = await db.query(
            "UPDATE UserProfile SET fName = ? WHERE userID = ?",
            [newFName, userID]
        );

        if (updateResult.affectedRows === 0) {
            return res.status(500).json({ error: "Failed to update name" });
        }

        res.json({ message: "First name updated successfully!" });

    } catch (err) {
        console.error("UPDATE NAME ERROR:", err);
        res.status(500).json({ error: "Server error", detail: err.message });
    }
});


/**
 * VIEW FIRST NAME BY USER ID
 */
router.get("/:userID", async (req, res) => {
  try {
    const { userID } = req.params;

    const [rows] = await db.query(
      "SELECT fName FROM UserProfile WHERE userID = ?",
      [userID]
    );

    if (rows.length === 0) {
      return res.status(404).send("User not found");
    }

    res.send(rows[0].fName);  // ONLY the first name
  } catch (err) {
    console.error("VIEW USER ERROR:", err);
    res.status(500).send("Server error");
  }
});



module.exports = router;