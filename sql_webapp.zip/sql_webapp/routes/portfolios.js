// routes/portfolios.js
const express = require("express");
const router = express.Router();
const db = require("../db");

/**
 * CREATE PORTFOLIO
 */
router.post("/", async (req, res) => {
    try {
        const { userID, baseCurrency } = req.body;

        if (!userID) {
            return res.status(400).json({ error: "userID is required" });
        }

        // OPTIONAL: verify that user exists before creating portfolio
        const [userCheck] = await db.query(
            "SELECT userID FROM UserProfile WHERE userID = ?",
            [userID]
        );

        if (userCheck.length === 0) {
            return res.status(404).json({ error: "User does not exist" });
        }

        const sql = `
            INSERT INTO Portfolio (baseCurrency, userID)
            VALUES (?, ?)
        `;

        const [result] = await db.query(sql, [
            baseCurrency || null,
            userID
        ]);

        return res.json({
            message: "Portfolio created",
            portfolioID: result.insertId
        });

    } catch (err) {
        console.error("Create portfolio error:", err);
        res.status(500).json({ error: "Failed to create portfolio" });
    }
});


// GET portfolios for a specific user
router.get("/user/:userID", async (req, res) => {
    try {
        const [rows] = await db.query(
            "SELECT * FROM Portfolio WHERE userID = ?",
            [req.params.userID]
        );
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: "Could not fetch user portfolios" });
    }
});



/**
 * DELETE PORTFOLIO
 */
router.delete("/:id", async (req, res) => {
    try {
        const id = req.params.id;

        const [result] = await db.query(
            "DELETE FROM Portfolio WHERE portfolioID = ?",
            [id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: "Portfolio not found" });
        }

        res.json({ message: `Portfolio ${id} deleted` });
    } catch (err) {
        res.status(500).json({ error: "Failed to delete portfolio" });
    }
});

/**
 * INTERESTING QUERY:
 * Total market value per portfolio
 * Not used for now
 */
router.get("/analytics/values", async (req, res) => {
    try {
        const sql = `
            SELECT 
                p.portfolioID,
                p.userID,
                SUM(h.marketValue) AS totalMarketValue
            FROM Portfolio p
            LEFT JOIN Holding h 
                ON p.portfolioID = h.portfolioID
            GROUP BY p.portfolioID
            ORDER BY totalMarketValue DESC
        `;

        const [rows] = await db.query(sql);
        res.json({ rows });

    } catch (err) {
        console.error("Analytics error:", err);
        res.status(500).json({ error: "Analytics query failed" });
    }
});

module.exports = router;
