// routes/accounts.js
const express = require("express");
const router = express.Router();
const db = require("../db");

/**
 * CREATE ACCOUNT
 */
router.post("/", async (req, res) => {
    try {
        const { accountID, userID, accountType } = req.body;

        if (!accountID || accountID.length !== 12) {
            return res.status(400).json({ error: "accountID must be exactly 12 characters" });
        }

        if (!userID) {
            return res.status(400).json({ error: "userID is required" });
        }

        if (!accountType) {
            return res.status(400).json({ error: "accountType is required" });
        }

        // Check if user exists
        const [userCheck] = await db.query(
            "SELECT userID FROM UserProfile WHERE userID = ?",
            [userID]
        );

        if (userCheck.length === 0) {
            return res.status(404).json({ error: "User does not exist" });
        }

        const sql = `
            INSERT INTO Account (accountID, accountType, userID)
            VALUES (?, ?, ?)
        `;

        await db.query(sql, [accountID, accountType, userID]);

        return res.json({
            message: "Account created",
            accountID: accountID
        });

    } catch (err) {
        console.error("Create account error:", err);
        res.status(500).json({ error: "Failed to create account" });
    }
});

/**
 * GET ACCOUNTS FOR A SPECIFIC USER
 */
router.get("/user/:userID", async (req, res) => {
    try {
        const [rows] = await db.query(
            "SELECT * FROM Account WHERE userID = ?",
            [req.params.userID]
        );

        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: "Could not load accounts" });
    }
});


/**
 * DELETE ACCOUNT
 */
router.delete("/:accountID", async (req, res) => {
    try {
        const id = req.params.accountID;

        const [result] = await db.query(
            "DELETE FROM Account WHERE accountID = ?",
            [id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: "Account not found" });
        }

        res.json({ message: `Account ${id} deleted` });
    } catch (err) {
        console.error("Delete account error:", err);
        res.status(500).json({ error: "Failed to delete account" });
    }
});

module.exports = router;
