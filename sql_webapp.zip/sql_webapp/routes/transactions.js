// routes/transactions.js
const express = require("express");
const router = express.Router();
const db = require("../db");

/**
 * CREATE TRANSACTION
 */
router.post("/", async (req, res) => {
  try {
    const {
      transactionID,
      portfolioID,
      tickerSymbol,
      investmentType,
      marketPricePerShare,
      salePricePerShare,
      quantity,
      transactionDate
    } = req.body;

    if (!transactionID || !portfolioID || !tickerSymbol || !marketPricePerShare || !quantity || !transactionDate) {
      return res.status(400).send("Missing required fields");
    }

    const sql = `
      INSERT INTO TransactionRecord
      (transactionID, portfolioID, tickerSymbol, investmentType,
       marketPricePerShare, salePricePerShare, quantity, transactionDate)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;

    await db.query(sql, [
      transactionID,
      portfolioID,
      tickerSymbol,
      investmentType || null,
      marketPricePerShare,
      salePricePerShare || null,
      quantity,
      transactionDate
    ]);

    return res.send(`Transaction created with ID: ${transactionID}`);
  } catch (err) {
    console.error("TRANSACTION CREATE ERROR:", err);
    res.status(500).send("Database error");
  }
});

/**
 * VIEW TRANSACTION
 */
router.get("/:transactionID", async (req, res) => {
  try {
    const { transactionID } = req.params;

    const [rows] = await db.query(
      "SELECT * FROM TransactionRecord WHERE transactionID = ?",
      [transactionID]
    );

    if (rows.length === 0) {
      return res.status(404).send("Transaction not found");
    }

    res.json(rows[0]);
  } catch (err) {
    console.error("VIEW TRANSACTION ERROR:", err);
    res.status(500).send("Server error");
  }
});

module.exports = router;
