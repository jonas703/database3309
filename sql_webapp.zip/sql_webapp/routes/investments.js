// routes/investments.js
const express = require("express");
const router = express.Router();
const db = require("../db");

/**
 * CREATE INVESTMENT
 */
router.post("/", async (req, res) => {
  try {
    const { tickerSymbol, sector, region, nativeCurrency, investmentType } = req.body;

    if (!tickerSymbol || !sector || !region || !investmentType) {
      return res.status(400).send("Missing required fields");
    }

    const sql = `
      INSERT INTO Investment (tickerSymbol, sector, region, nativeCurrency, investmentType)
      VALUES (?, ?, ?, ?, ?)
    `;

    await db.query(sql, [
      tickerSymbol,
      sector,
      region,
      nativeCurrency || "USD",
      investmentType
    ]);

    return res.send(`Investment created with symbol: ${tickerSymbol}`);
  } catch (err) {
    console.error("INVESTMENT CREATE ERROR:", err);
    res.status(500).send("Database error");
  }
});

/**
 * VIEW INVESTMENT
 */
router.get("/:tickerSymbol", async (req, res) => {
  try {
    const { tickerSymbol } = req.params;

    const [rows] = await db.query(
      "SELECT * FROM Investment WHERE tickerSymbol = ?",
      [tickerSymbol]
    );

    if (rows.length === 0) {
      return res.status(404).send("Investment not found");
    }

    res.json(rows[0]); // return full investment row
  } catch (err) {
    console.error("VIEW INVESTMENT ERROR:", err);
    res.status(500).send("Server error");
  }
});

module.exports = router;
