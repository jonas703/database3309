// app.js
require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const db = require('./db'); // expects pool
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// ========== Helpers ==========
function validatePassword(pw) {
  if (!pw || pw.length < 8) return 'Password must be at least 8 characters';
  if (!(/\d/.test(pw))) return 'Password must contain at least one digit';
  return null;
}

// ========== API Endpoints ==========

// 1) Add User (INSERT) - POST /api/users
app.post('/api/users', async (req, res) => {
  try {
    const { password, fName = null, lName = null, dateOfBirth } = req.body;
    const v = validatePassword(password);
    if (v) return res.status(400).json({ error: v });
    if (!dateOfBirth) return res.status(400).json({ error: 'dateOfBirth is required (YYYY-MM-DD)' });

    const [result] = await db.execute(
      'INSERT INTO UserProfile (password, fName, lName, dateOfBirth) VALUES (?, ?, ?, ?)',
      [password, fName, lName, dateOfBirth]
    );
    const userID = result.insertId;
    const [rows] = await db.execute('SELECT userID, fName, lName, dateOfBirth FROM UserProfile WHERE userID = ?', [userID]);
    res.json({ success: true, user: rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error', details: err.message });
  }
});

// 2) Create Portfolio (INSERT) - POST /api/portfolios
app.post('/api/portfolios', async (req, res) => {
  try {
    const { baseCurrency = null, userID } = req.body;
    if (!userID) return res.status(400).json({ error: 'userID is required' });

    // check user exists
    const [u] = await db.execute('SELECT userID FROM UserProfile WHERE userID = ?', [userID]);
    if (u.length === 0) return res.status(400).json({ error: `User ${userID} not found` });

    const [result] = await db.execute(
      'INSERT INTO Portfolio (baseCurrency, userID) VALUES (?, ?)',
      [baseCurrency, userID]
    );
    const portfolioID = result.insertId;
    const [rows] = await db.execute('SELECT * FROM Portfolio WHERE portfolioID = ?', [portfolioID]);
    res.json({ success: true, portfolio: rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error', details: err.message });
  }
});

// 3) Add Transaction (INSERT) + adjust Holding (complex, uses transaction) - POST /api/transactions
app.post('/api/transactions', async (req, res) => {
  const conn = await db.getConnection();
  try {
    const {
      portfolioID,
      tickerSymbol,
      investmentType = null,
      marketPricePerShare,
      salePricePerShare = null,
      quantity,
      transactionDate,
      action // 'Buy' or 'Sell' expected from UI
    } = req.body;

    if (!portfolioID || !tickerSymbol || !marketPricePerShare || !quantity || !transactionDate || !action) {
      conn.release();
      return res.status(400).json({ error: 'portfolioID, tickerSymbol, marketPricePerShare, quantity, transactionDate, action are required' });
    }

    await conn.beginTransaction();

    // generate a new transactionID because schema does not have AUTO_INCREMENT
    const [rowsMax] = await conn.query('SELECT IFNULL(MAX(transactionID), 0) AS mx FROM TransactionRecord');
    const nextId = (rowsMax[0].mx || 0) + 1;

    await conn.execute(
      `INSERT INTO TransactionRecord
       (transactionID, portfolioID, tickerSymbol, investmentType, marketPricePerShare, salePricePerShare, quantity, transactionDate)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [nextId, portfolioID, tickerSymbol, investmentType, marketPricePerShare, salePricePerShare, quantity, transactionDate]
    );

    // Update or insert into Holding: simple logic:
    // If Buy -> increase quantity; if Sell -> decrease quantity
    const sign = action.toLowerCase() === 'sell' ? -1 : 1;
    const qtyDelta = Number(quantity) * sign;

    const [existing] = await conn.execute(
      'SELECT quantityOwned, bookCost FROM Holding WHERE portfolioID = ? AND tickerSymbol = ? FOR UPDATE',
      [portfolioID, tickerSymbol]
    );

    if (existing.length === 0) {
      // create
      const bookCost = Number(marketPricePerShare) * Number(quantity); // simple book cost
      const marketValue = Number(marketPricePerShare) * Number(quantity);
      await conn.execute(
        'INSERT INTO Holding (portfolioID, tickerSymbol, quantityOwned, bookCost, marketValue) VALUES (?, ?, ?, ?, ?)',
        [portfolioID, tickerSymbol, qtyDelta, bookCost, marketValue]
      );
    } else {
      // update
      const currentQty = Number(existing[0].quantityOwned);
      const newQty = currentQty + qtyDelta;
      if (newQty < 0) {
        await conn.rollback();
        conn.release();
        return res.status(400).json({ error: 'Insufficient quantity in holding to perform this sell.' });
      }
      // naive book cost update: weighted average for buys; for sells leave bookCost proportional
      let newBookCost = Number(existing[0].bookCost);
      if (sign > 0) {
        // buy => add to book cost
        newBookCost = newBookCost + (Number(marketPricePerShare) * Number(quantity));
      } else {
        // sell => reduce book cost proportionally (simple)
        const proportionRemaining = newQty === 0 ? 0 : newQty / currentQty;
        newBookCost = newBookCost * proportionRemaining;
      }
      const newMarketValue = newQty * Number(marketPricePerShare);
      await conn.execute(
        'UPDATE Holding SET quantityOwned = ?, bookCost = ?, marketValue = ? WHERE portfolioID = ? AND tickerSymbol = ?',
        [newQty, newBookCost, newMarketValue, portfolioID, tickerSymbol]
      );
    }

    await conn.commit();
    conn.release();

    res.json({ success: true, transactionID: nextId, message: 'Transaction recorded and holdings updated.' });
  } catch (err) {
    await conn.rollback().catch(()=>{});
    conn.release();
    console.error(err);
    res.status(500).json({ error: 'Database error', details: err.message });
  }
});

// 4) Update Holding (UPDATE) - PUT /api/holdings
app.put('/api/holdings', async (req, res) => {
  try {
    const { portfolioID, tickerSymbol, quantityOwned, bookCost } = req.body;
    if (!portfolioID || !tickerSymbol) return res.status(400).json({ error: 'portfolioID and tickerSymbol required' });
    const sets = [];
    const params = [];
    if (quantityOwned !== undefined) { sets.push('quantityOwned = ?'); params.push(quantityOwned); }
    if (bookCost !== undefined) { sets.push('bookCost = ?'); params.push(bookCost); }
    if (sets.length === 0) return res.status(400).json({ error: 'Nothing to update' });

    // naive marketValue recompute if quantity and we have no market price, keep existing marketValue
    const sql = `UPDATE Holding SET ${sets.join(', ')} WHERE portfolioID = ? AND tickerSymbol = ?`;
    params.push(portfolioID, tickerSymbol);
    const [result] = await db.execute(sql, params);
    res.json({ success: true, affectedRows: result.affectedRows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error', details: err.message });
  }
});

// 5) Delete Account (DELETE) - DELETE /api/accounts/:accountID
app.delete('/api/accounts/:id', async (req, res) => {
  try {
    const accountID = req.params.id;
    const [result] = await db.execute('DELETE FROM Account WHERE accountID = ?', [accountID]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Account not found' });
    res.json({ success: true, deletedAccountID: accountID });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error', details: err.message });
  }
});

// 6) Filtered search for Investments (SELECT with WHERE & client controls) - GET /api/investments
app.get('/api/investments', async (req, res) => {
  try {
    const { q = '', sector = '', region = '', type = '' } = req.query;
    const where = [];
    const params = [];
    if (q) { where.push('(tickerSymbol LIKE ? OR nativeCurrency LIKE ?)'); params.push(`%${q}%`, `%${q}%`); }
    if (sector) { where.push('sector = ?'); params.push(sector); }
    if (region) { where.push('region = ?'); params.push(region); }
    if (type) { where.push('investmentType = ?'); params.push(type); }
    const sql = `SELECT * FROM Investment ${where.length ? 'WHERE ' + where.join(' AND ') : ''} LIMIT 200`;
    const [rows] = await db.execute(sql, params);
    res.json({ results: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error', details: err.message });
  }
});

// 7) Joined Report: holdings joined with investment, portfolio, and user (JOIN)
app.get('/api/reports/joined-holdings', async (req, res) => {
  try {
    const sql = `
      SELECT h.portfolioID, p.userID, u.fName, u.lName,
             h.tickerSymbol, i.sector, i.region, i.investmentType, h.quantityOwned, h.bookCost, h.marketValue
      FROM Holding h
      JOIN Investment i ON h.tickerSymbol = i.tickerSymbol
      JOIN Portfolio p ON h.portfolioID = p.portfolioID
      JOIN UserProfile u ON p.userID = u.userID
      ORDER BY u.userID, h.portfolioID, h.tickerSymbol
      LIMIT 500
    `;
    const [rows] = await db.execute(sql);
    res.json({ rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error', details: err.message });
  }
});

// 8) Aggregation report: total marketValue per sector (GROUP BY)
app.get('/api/reports/sector-aggregate', async (req, res) => {
  try {
    const sql = `
      SELECT i.sector,
             COUNT(*) AS holdingsCount,
             SUM(h.marketValue) AS totalMarketValue,
             SUM(h.bookCost) AS totalBookCost
      FROM Holding h
      JOIN Investment i ON h.tickerSymbol = i.tickerSymbol
      GROUP BY i.sector
      ORDER BY totalMarketValue DESC
    `;
    const [rows] = await db.execute(sql);
    res.json({ rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error', details: err.message });
  }
});

// Serve SPA index (fallback)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Server listening on ${PORT}`);
});
