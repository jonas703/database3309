// db.js
const mysql = require("mysql2/promise");
require("dotenv").config();

const pool = mysql.createPool({
  host: process.env.DB_HOST || '136.113.83.204',
  user: process.env.DB_USER || 'rich',
  password: process.env.DB_PASSWORD || 'Test-Pass1',
  database: process.env.DB_NAME || '3309Grp13',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  ssl: {
    rejectUnauthorized: false   // <-- REQUIRED FOR CLOUD SQL
  }
});

module.exports = pool;
