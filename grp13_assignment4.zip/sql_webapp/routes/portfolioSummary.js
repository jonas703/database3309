// routes/portfolioSummary.js
const express = require("express");
const router = express.Router();
const db = require("../db");

router.get("/:portfolioID", async (req, res) => {
  try {
    const portfolioID = req.params.portfolioID;
    if (!portfolioID) return res.status(400).send("Missing portfolioID");

    const sql = `SELECT * FROM PortfolioSummary WHERE portfolioID = ?`;
    const [rows] = await db.query(sql, [portfolioID]);

    if (!rows || rows.length === 0) {
      return res.status(404).send("No data found for this portfolio.");
    }

    res.json(rows);
  } catch (err) {
    console.error("PORTFOLIO SUMMARY ERROR:", err);
    res.status(500).send("Database error");
  }
});

module.exports = router;
