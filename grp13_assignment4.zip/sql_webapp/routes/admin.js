// routes/admin.js
const express = require("express");
const router = express.Router();
const db = require("../db");

// SET risk profile
router.post("/", async (req, res) => {
    try {
        const { userID, desiredRiskProfile } = req.body;

        const sql = `
            INSERT INTO AdminUser (userID, desiredRiskProfile)
            VALUES (?, ?)
        `;

        await db.query(sql, [userID, desiredRiskProfile]);

        res.json({ message: "Risk profile added" });

    } catch (err) {
        res.status(500).json({ error: "Failed to add admin profile" });
    }
});

// GET risk profile
router.get("/:id", async (req, res) => {
    try {
        const [rows] = await db.query(
            "SELECT * FROM AdminUser WHERE userID = ?",
            [req.params.id]
        );
        res.json(rows[0] || null);
    } catch (err) {
        res.status(500).json({ error: "Fetch failed" });
    }
});

module.exports = router;
