const express = require("express");
const router = express.Router();
const db = require("../db");

// CALL STORED PROCEDURE GetRiskAnalysis(userID)
router.get("/:userID", async (req, res) => {
    try {
        const userID = req.params.userID;

        if (!userID) {
            return res.status(400).send("Missing userID");
        }

        // CALL the stored procedure
        const [rows] = await db.query("CALL GetRiskAnalysis(?)", [userID]);
        //Premade Query contains joins

        // MySQL returns an array: [ [results], metadata ]
        const result = rows[0];

        // If no holdings
        if (!result || result.length === 0) {
            return res.status(404).send("No holdings found for this user.");
        }

        // Send as JSON
        res.json(result);

    } catch (err) {
        console.error("RISK PROCEDURE ERROR:", err);
        res.status(500).send("Server error: " + err.message);
    }
});

module.exports = router;
