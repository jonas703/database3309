// routes/transactions.js
const express = require("express");
const router = express.Router();
const db = require("../db");

/**
 * CREATE TRANSACTION
 */
router.post("/", async (req, res) => {
  try {
    const {
      transactionID,
      portfolioID,
      tickerSymbol,
      investmentType,
      marketPricePerShare,
      salePricePerShare,
      quantity,
      transactionDate
    } = req.body;

    // ======================================
    // BASIC REQUIRED FIELD CHECK
    // ======================================
    if (!transactionID || !portfolioID || !tickerSymbol || !marketPricePerShare || !quantity || !transactionDate) {
      return res.status(400).send("Missing required fields");
    }

    // ======================================
    // MANUAL VALIDATION (based on DB limits)
    // ======================================

    // transactionID must be <= 10 digits
    if (String(transactionID).length > 10) {
      return res.status(400).send("Error: transactionID cannot exceed 10 digits.");
    }

    // tickerSymbol max length = 10
    if (tickerSymbol.length > 10) {
      return res.status(400).send("Error: tickerSymbol cannot exceed 10 characters.");
    }

    // investmentType max length = 50
    if (investmentType && investmentType.length > 50) {
      return res.status(400).send("Error: investmentType cannot exceed 50 characters.");
    }

    // quantity cannot be negative
    if (quantity < 0) {
      return res.status(400).send("Error: quantity must be positive.");
    }

    // ======================================
    // INSERT QUERY
    // ======================================

    const sql = `
      INSERT INTO TransactionRecord
      (transactionID, portfolioID, tickerSymbol, investmentType,
       marketPricePerShare, salePricePerShare, quantity, transactionDate)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;

    await db.query(sql, [
      transactionID,
      portfolioID,
      tickerSymbol,
      investmentType || null,
      marketPricePerShare,
      salePricePerShare || null,
      quantity,
      transactionDate
    ]);

    return res.send(`Transaction created with ID: ${transactionID}`);
  } 
  
  catch (err) {
    console.error("TRANSACTION CREATE ERROR:", err);

    // ======================================
    // FOREIGN KEY ERROR — Missing ticker
    // ======================================
    if (err.errno === 1452 || err.code === "ER_NO_REFERENCED_ROW_2") {
      return res.status(400).send(
        "Error: Ticker symbol does not exist in Investment table. Please insert a valid ticker."
      );
    }

    // Duplicate transaction ID
    if (err.code === "ER_DUP_ENTRY") {
      return res.status(400).send(
        "Error: transactionID already exists. Please use a unique transactionID."
      );
    }

    // Default MySQL error
    return res.status(500).send("Database error");
  }
});

/**
 * VIEW TRANSACTION (returns HTML table)
 */
router.get("/:transactionID", async (req, res) => {
  try {
    const { transactionID } = req.params;

    const [rows] = await db.query(
      "SELECT * FROM TransactionRecord WHERE transactionID = ?",
      [transactionID]
    );

    if (rows.length === 0) {
      return res.status(404).send("Transaction not found");
    }

    const data = rows[0];

    // Build HTML table dynamically
    let tableHTML = `
      <html>
      <head>
        <title>Transaction ${transactionID}</title>
        <style>
          body { font-family: Arial; padding: 20px; }
          table { border-collapse: collapse; width: 400px; }
          td, th { border: 1px solid #ccc; padding: 8px; }
          th { background: #f2f2f2; text-align: left; }
        </style>
      </head>
      <body>
        <h2>Transaction Details</h2>
        <table>
          ${Object.entries(data)
            .map(
              ([key, value]) => `
            <tr>
              <th>${key}</th>
              <td>${value}</td>
            </tr>
          `
            )
            .join("")}
        </table>
      </body>
      </html>
    `;

    res.send(tableHTML);
  } catch (err) {
    console.error("VIEW TRANSACTION ERROR:", err);
    res.status(500).send("Server error");
  }
});


module.exports = router;
